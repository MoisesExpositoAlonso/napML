message("Compile Rcpp attributes")
Rcpp::compileAttributes()
