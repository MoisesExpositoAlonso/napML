#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>
#include <list>
#include <iostream>
#include <string>

#include <fstream>
#include <sstream>

#include <RcppArmadillo.h>
#include <RcppEigen.h>

Rcpp::RNGScope scope;
using namespace Rcpp;

#include <bigmemory/MatrixAccessor.hpp>
#include <bigmemory/isna.hpp>

////////////////////////////////////////////////////////////////////////////////
//  ABOVE FOR MY INCLUSIONS
// BELOW FOR INCLUSIONS OF PLINK2R
// #include <iostream>
// #include <fstream>
// #include <vector>
// #include <algorithm>
//
// #include <Eigen/Core>
// #include <Eigen/Dense>
// #include <Eigen/Eigen>
// #include <Eigen/SVD>
// #include <Eigen/Sparse>
//
//
// #include <fcntl.h>
// #include <stdexcept>
//
//
// #include <RcppEigen.h>
// using namespace Rcpp;
// using namespace Eigen;
////////////////////////////////////////////////////////////////////////////////



#define PACK_DENSITY 4
#define PLINK_NA 3

#define PLINK_PHENO_MISSING -9

// The BED file magic numbers
#define PLINK_OFFSET 3

#define COVAR_ACTION_TRAIN_TEST 0
#define COVAR_ACTION_TRAIN_ONLY 1


/* 3 is 11 in binary, we need a 2 bit mask for each of the 4 positions */
#define MASK0 3	  /* 3 << 2 * 0 */
#define MASK1 12  /* 3 << 2 * 1 */
#define MASK2 48  /* 3 << 2 * 2 */
#define MASK3 192 /* 3 << 2 * 3 */

#define BUFSIZE 100


/*
 *                   plink BED           sparsnp
 * minor homozyous:  00 => numeric 0     10 => numeric 2
 * heterozygous:     10 => numeric 2     01 => numeric 1
 * major homozygous: 11 => numeric 3     00 => numeric 0
 * missing:          01 => numeric 1     11 => numeric 3
 *
 *
 * http://pngu.mgh.harvard.edu/~purcell/plink/binary.shtml says,
 * The bytes in plink are read backwards HGFEDCBA, not GHEFCDAB, but we read
 * them forwards as a character (a proper byte)
 *
 * By default, plink usage dosage of the *major* allele, since allele A1 is
 * usually the minor allele and the code "1" refers to the second allele A2,
 * so that "11" is A2/A2 or major/major.
 *
 * We always use minor allele dosage, to be consistent with the output from
 * plink --recodeA which used minor allele dosage by default.
 *
 * out: array of genotypes
 * in: array of packed genotypes (bytes)
 * n: number of bytes in input
 *
 */
void decode_plink(unsigned char *out,
      const unsigned char *in, const unsigned int n)
{
   unsigned int i, k;
   unsigned char tmp, geno;
   unsigned int a1, a2;

   for(i = 0 ; i < n ; ++i){
      tmp = in[i];
      k = PACK_DENSITY * i;

      /* geno is interpreted as a char, however a1 and a2 are bits for allele 1 and
       * allele 2. The final genotype is the sum of the alleles, except for 01
       * which denotes missing.
       */
      geno = (tmp & MASK0);
      a1 = !(geno & 1);
      a2 = !(geno >> 1);
      out[k] = (geno == 1) ? 3 : a1 + a2;
      k++;

      geno = (tmp & MASK1) >> 2;
      a1 = !(geno & 1);
      a2 = !(geno >> 1);
      out[k] = (geno == 1) ? 3 : a1 + a2;
      k++;

      geno = (tmp & MASK2) >> 4;
      a1 = !(geno & 1);
      a2 = !(geno >> 1);
      out[k] = (geno == 1) ? 3 : a1 + a2;
      k++;

      geno = (tmp & MASK3) >> 6;
      a1 = !(geno & 1);
      a2 = !(geno >> 1);
      out[k] = (geno == 1) ? 3 : a1 + a2;
   }
}

// [[Rcpp::export]]
int BMreadbed(std::string bedfile,
              SEXP G,
              unsigned int N=1011, // number of individuals
              unsigned int p=83794, // number of SNPs
              bool verbose=true){
   ////////////////////////////////////////////////////
   // Opening backing file
   Rcpp::XPtr<BigMatrix> bigMat(G);
   MatrixAccessor<double> macc(*bigMat);
   ////////////////////////////////////////////////////
   // Initializing
   unsigned long len;
   unsigned int np, nsnps, ncovar;
  ////////////////////////////////////////////////////
  // Opening binary file
   std::ifstream in(bedfile, std::ios::in | std::ios::binary);
   if(!in){
      std::cerr << "[read_bed] Error reading file " << bedfile << std::endl;
      throw std::runtime_error("io error");
   }
   in.seekg(0, std::ifstream::end);
   // file size in bytes, ignoring first 3 bytes (2byte magic number + 1byte mode)
   len = (unsigned int)in.tellg() - 3;
   std::cout << "The size in bytes of the file is: " << len<< std::endl;
  ////////////////////////////////////////////////////
  // Iterating

   // size of packed data, in bytes, per SNP
   np = (unsigned int)ceil((double)N / (double)PACK_DENSITY);
   std::cout << "Size in bytes of SNP packs is: " << np << std::endl;
   nsnps = len / np;
   in.seekg(3, std::ifstream::beg);

   unsigned char* tmp = new unsigned char[np];

  // Allocate more than the sample size since data must take up whole bytes
   unsigned char* tmp2 = new unsigned char[np * PACK_DENSITY];
    for(unsigned int j = 0 ; j < nsnps ; j++){
    in.read((char*)tmp, sizeof(char) * np);
    decode_plink(tmp2, tmp, np);
      for(unsigned int i = 0 ; i < N ; i++){
        // std::cout << (double)tmp2[i] << std::endl;
        macc[j][i] = (double)tmp2[i];
      }
    }
   in.close();
  return 1;
}

// [[Rcpp::export]]
int printbed(std::string bedfile,
              unsigned int N=1011, // number of individuals
              unsigned int p=83794, // number of SNPs
              bool verbose=true){
   ////////////////////////////////////////////////////
   // Initializing
   unsigned long len;
   unsigned int np, nsnps, ncovar;
  ////////////////////////////////////////////////////
  // Opening binary file
   std::ifstream in(bedfile, std::ios::in | std::ios::binary);
   if(!in){
      std::cerr << "[read_bed] Error reading file " << bedfile << std::endl;
      throw std::runtime_error("io error");
   }
   in.seekg(0, std::ifstream::end);
   // file size in bytes, ignoring first 3 bytes (2byte magic number + 1byte mode)
   len = (unsigned int)in.tellg() - 3;
   std::cout << "The size in bytes of the file is: " << len<< std::endl;
  ////////////////////////////////////////////////////
  // Iterating

   // size of packed data, in bytes, per SNP
   np = (unsigned int)ceil((double)N / (double)PACK_DENSITY);
   std::cout << "Size in bytes of SNP packs is: " << np << std::endl;
   nsnps = len / np;
   in.seekg(3, std::ifstream::beg);

   unsigned char* tmp = new unsigned char[np];

 // Allocate more than the sample size since data must take up whole bytes
   unsigned char* tmp2 = new unsigned char[np * PACK_DENSITY];
   // Rcpp::NumericVector tmp3(N); // in original used Eigen

    for(unsigned int j = 0 ; j < nsnps ; j++){ // but only first 10 blocks
    in.read((char*)tmp, sizeof(char) * np);
    // std::cout<< tmp << std::endl; // prints as cat in terminal
    decode_plink(tmp2, tmp, np);
      for(unsigned int i = 0 ; i < N ; i++){ // go over 10 individuals individuals
        // tmp3(i) = (double)tmp2[i];
        std::cout << (double)tmp2[i] << std::endl;
      }
    }
   in.close();
  return 1;
}

